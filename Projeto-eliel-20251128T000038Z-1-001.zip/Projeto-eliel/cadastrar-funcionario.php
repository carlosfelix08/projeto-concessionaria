<div class="conteudo-painel">
    <h1>Cadastrar Funcionário</h1>
    <form action="?page=salvar-funcionario" method="POST">
        <input type='hidden' name='acao' value='cadastrar'>
        
        <div class='mb-3'>
            <label class="form-label">Nome</label>
            <input type='text' name='nome_funcionario' class='form-control' placeholder="Nome completo">
        </div>
        
        <div class='mb-3'>
            <label class="form-label">E-mail</label>
            <input type='email' name='email_funcionario' class='form-control' placeholder="exemplo@email.com">
        </div>
        
        <div class='mb-3'>
            <label class="form-label">Telefone</label>
            <input type='text' name='telefone_funcionario' class='form-control' placeholder="(00) 00000-0000">
        </div>
        
        <div class="mt-4">
            <button type='submit' class='btn btn-primary'>Salvar Cadastro</button>
        </div>
    </form>
</div>