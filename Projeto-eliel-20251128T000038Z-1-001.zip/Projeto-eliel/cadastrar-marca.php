<div class="conteudo-painel">
    <h1>Cadastrar Marca</h1>
    <form action="?page=salvar-marca" method="POST">
        <input type='hidden' name='acao' value='cadastrar'>
        
        <div class='mb-3'>
            <label class="form-label">Nome da Marca</label>
            <input type='text' name='nome_marca' class='form-control' placeholder="Ex: Chevrolet, Ford, Toyota...">
        </div>
        
        <div class="mt-4">
            <button type='submit' class='btn btn-primary'>Salvar Cadastro</button>
        </div>
    </form>
</div>