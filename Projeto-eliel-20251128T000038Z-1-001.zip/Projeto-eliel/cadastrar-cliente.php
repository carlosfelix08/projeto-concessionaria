<div class="conteudo-painel">
    <h1>Cadastrar Cliente</h1>
    <form action="?page=salvar-cliente" method="POST">
        <input type='hidden' name='acao' value='cadastrar'>
        
        <div class='mb-3'>
            <label class="form-label">Nome</label>
            <input type='text' name='nome_cliente' class='form-control' placeholder="Nome completo">
        </div>
        
        <div class='mb-3'>
            <label class="form-label">CPF (Somente números)</label>
            <input type='text' name='cpf_cliente' class='form-control' maxlength="11" placeholder="Ex: 12345678900">
        </div>
        
        <div class='mb-3'>
            <label class="form-label">E-mail</label>
            <input type='email' name='email_cliente' class='form-control' placeholder="email@exemplo.com">
        </div>
        
        <div class='mb-3'>
            <label class="form-label">Telefone</label>
            <input type='text' name='telefone_cliente' class='form-control' placeholder="(00) 00000-0000">
        </div>
        
        <div class='mb-3'>
            <label class="form-label">Endereço</label>
            <input type='text' name='endereco_cliente' class='form-control' placeholder="Rua, Número, Bairro">
        </div>
        
        <div class='mb-3'>
            <label class="form-label">Data de Nascimento</label>
            <input type='date' name='dt_nasc_cliente' class='form-control'>
        </div>
        
        <div class="mt-4">
            <button type='submit' class='btn btn-primary'>Salvar Cadastro</button>
        </div>
    </form>
</div>