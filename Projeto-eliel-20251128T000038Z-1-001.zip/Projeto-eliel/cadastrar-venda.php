<div class="conteudo-painel">
    <h1>Cadastrar Venda</h1>
    <form action="?page=salvar-venda" method="POST">
        <input type="hidden" name="acao" value="cadastrar">
        
        <div class="mb-3">
            <label class="form-label">Cliente</label>
            <select name="cliente_id_cliente" class="form-select">
                <option selected>-= Escolha o Cliente =-</option>
                <?php
                    $sql = "SELECT * FROM cliente";
                    $res = $conn->query($sql);
                    $qtd = $res->num_rows;
                    if($qtd > 0){
                        while($row = $res->fetch_object()){
                            print "<option value='{$row->id_cliente}'>{$row->nome_cliente}</option>";
                        }
                    }else{
                        print "<option>Não há clientes registrados</option>";
                    }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Funcionário</label>
            <select name="funcionario_id_funcionario" class="form-select">
                <option selected>-= Escolha o Funcionário =-</option>
                <?php
                    $sql = "SELECT * FROM funcionario";
                    $res = $conn->query($sql);
                    $qtd = $res->num_rows;
                    if($qtd > 0){
                        while($row = $res->fetch_object()){
                            print "<option value='{$row->id_funcionario}'>{$row->nome_funcionario}</option>";
                        }
                    }else{
                        print "<option>Não há funcionários registrados</option>";
                    }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Modelo do Carro</label>
            <select name="modelo_id_modelo" class="form-select">
                <option selected>-= Escolha o Modelo =-</option>
                <?php
                    $sql = "SELECT * FROM modelo";
                    $res = $conn->query($sql);
                    $qtd = $res->num_rows;
                    if($qtd > 0){
                        while($row = $res->fetch_object()){
                            print "<option value='{$row->id_modelo}'>{$row->nome_modelo}</option>";
                        }
                    }else{
                        print "<option>Não há modelos registrados</option>";
                    }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Data da Venda</label>
            <input type="date" name="data_venda" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label">Valor (R$)</label>
            <input type="number" step="0.01" name="valor_venda" class="form-control" placeholder="0.00">
        </div>

        <div class="mt-4">
            <button type="submit" class="btn btn-primary">Finalizar Venda</button>
        </div>
    </form>
</div>