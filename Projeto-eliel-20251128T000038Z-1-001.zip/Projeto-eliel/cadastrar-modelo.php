<div class="conteudo-painel">
    <h1>Cadastrar Modelo</h1>
    <form action="?page=salvar-modelo" method="POST">
        <input type="hidden" name="acao" value="cadastrar">
        
        <div class="mb-3">
            <label class="form-label">Marca</label>
            <select name="marca_id_marca" class="form-select">
                <option selected>-= Escolha a Marca =-</option>
                <?php
                    $sql = "SELECT * FROM marca";
                    $res = $conn->query($sql);
                    $qtd = $res->num_rows;
                    if($qtd > 0){
                        while($row = $res->fetch_object()){
                            print "<option value='{$row->id_marca}'>{$row->nome_marca}</option>";
                        }
                    }else{
                        print "<option value=''>Não há marcas registradas</option>";
                    }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Nome do Modelo</label>
            <input type="text" name="nome_modelo" class="form-control" placeholder="Ex: Celta, Corolla, Civic...">
        </div>

        <div class="mb-3">
            <label class="form-label">Cor</label>
            <input type="text" name="cor_modelo" class="form-control" placeholder="Cor do veículo">
        </div>

        <div class="mb-3">
            <label class="form-label">Ano</label>
            <input type="number" name="ano_modelo" class="form-control" placeholder="Ano de fabricação">
        </div>

        <div class="mb-3">
            <label class="form-label">Tipo</label>
            <input type="text" name="tipo_modelo" class="form-control" placeholder="Ex: Sedan, Hatch, SUV...">
        </div>

        <div class="mt-4">
            <button type="submit" class="btn btn-primary">Salvar Cadastro</button>
        </div>
    </form>
</div>