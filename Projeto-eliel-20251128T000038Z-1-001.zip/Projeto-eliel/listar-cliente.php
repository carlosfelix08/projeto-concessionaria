<div class="conteudo-painel">
    <h1>Listar Clientes</h1>
    <?php
        $sql = "SELECT * FROM cliente";
        $res = $conn->query($sql);
        $qtd = $res->num_rows;

        if($qtd > 0){
            print "<p> Encontrou <b>$qtd</b> resultado(s)</p>";
            print "<table class='table table-hover'>";
                print "<thead>";
                    print "<tr>";
                    print "<th>#</th>";
                    print "<th>Nome</th>";
                    print "<th>CPF</th>";
                    print "<th>E-mail</th>";
                    print "<th>Telefone</th>";
                    print "<th>Endereço</th>";
                    print "<th>Data de Nasc.</th>";
                    print "<th>Ações</th>";
                    print "</tr>";
                print "</thead>";
                
                print "<tbody>";
                while ($row = $res->fetch_object() ){
                    
                    $cpf_formatado = preg_replace("/(\d{3})(\d{3})(\d{3})(\d{2})/", "\$1.\$2.\$3-\$4", $row->cpf_cliente);

                    print "<tr>";
                    print "<td>".$row->id_cliente."</td>";
                    print "<td>".$row->nome_cliente."</td>";
                    print "<td>".$cpf_formatado."</td>";
                    print "<td>".$row->email_cliente."</td>";
                    print "<td>".$row->telefone_cliente."</td>";
                    print "<td>".$row->endereco_cliente."</td>";
                    print "<td>".date('d/m/Y', strtotime($row->dt_nasc_cliente))."</td>";
                    print "<td>
                            <button class='btn btn-outline-info btn-sm' onclick=\"location.href='?page=editar-cliente&id_cliente={$row->id_cliente}';\">Editar</button>

                            <button class='btn btn-outline-danger btn-sm' onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar-cliente&acao=excluir&id_cliente={$row->id_cliente}';}else{false;}\">Excluir</button>
                            </td>";
                    print "</tr>";
                }
                print "</tbody>";
            print "</table>";
        }else{
            print "<div class='alert alert-secondary'>Não encontrou resultados.</div>";
        }
    ?>
</div>