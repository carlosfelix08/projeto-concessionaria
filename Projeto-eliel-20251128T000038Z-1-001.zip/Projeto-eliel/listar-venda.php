<div class="conteudo-painel">
    <h1>Listar Vendas</h1>
    <?php
        $sql = "SELECT * FROM venda AS ve
            INNER JOIN cliente AS cli
            ON ve.cliente_id_cliente = cli.id_cliente
            INNER JOIN funcionario AS func
            ON ve.funcionario_id_funcionario = func.id_funcionario
            INNER JOIN modelo AS mo
            ON ve.modelo_id_modelo = mo.id_modelo";

        $res = $conn->query($sql);
        $qtd = $res->num_rows;

        if($qtd > 0){
            print "<p>Encontrou <b>$qtd</b> resultado(s)</p>";
            print "<table class='table table-hover'>";
                print "<thead>";
                    print "<tr>";
                    print "<th>#</th>";
                    print "<th>Cliente</th>";
                    print "<th>Funcionário</th>";
                    print "<th>Modelo</th>";
                    print "<th>Data</th>";
                    print "<th>Valor</th>";
                    print "<th>Ações</th>";
                    print "</tr>";
                print "</thead>";
                
                print "<tbody>";
                while($row = $res->fetch_object()){
                    print "<tr>";
                    print "<td>{$row->id_venda}</td>";
                    print "<td>{$row->nome_cliente}</td>";
                    print "<td>{$row->nome_funcionario}</td>";
                    print "<td>{$row->nome_modelo}</td>";
                    print "<td>".date('d/m/Y', strtotime($row->data_venda))."</td>";
                    print "<td>R$ ".number_format($row->valor_venda, 2, ',', '.')."</td>";
                    
                    print "<td>
                            <button class='btn btn-outline-info btn-sm' onclick=\"location.href='?page=editar-venda&id_venda={$row->id_venda}';\">Editar</button>

                            <button class='btn btn-outline-danger btn-sm' onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar-venda&acao=excluir&id_venda={$row->id_venda}';}else{false;}\">Excluir</button>
                            </td>";
                    print "</tr>";
                }
                print "</tbody>";
            print "</table>";
        }else{
            print "<div class='alert alert-secondary'>Não há vendas registradas.</div>";
        }
    ?>
</div>