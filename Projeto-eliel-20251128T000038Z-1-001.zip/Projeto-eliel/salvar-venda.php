<?php
	switch ($_REQUEST['acao']) {
			case 'cadastrar':
				$cliente_id_cliente = $_POST['cliente_id_cliente'];
				$funcionario_id_funcionario = $_POST['funcionario_id_funcionario'];
				$modelo_id_modelo = $_POST['modelo_id_modelo'];
				$data = $_POST['data_venda'];
				$valor = $_POST['valor_venda'];

				$sql = "INSERT INTO venda (cliente_id_cliente, funcionario_id_funcionario, modelo_id_modelo, data_venda, valor_venda) VALUES ('{$cliente_id_cliente}', '{$funcionario_id_funcionario}', '{$modelo_id_modelo}', '{$data}', {$valor})";

				$res = $conn->query($sql);

				if($res == true){
					print "<script>alert('Cadastrou com sucesso');</script>";
					print "<script>location.href='?page=listar-venda';</script>";
				}else{
					print "<script>alert('Não cadastrou');</script>";
					print "<script>location.href='?page=listar-venda';</script>";
				}
				break;
			
			case 'editar':
				$cliente_id_cliente = $_POST['cliente_id_cliente'];
				$funcionario_id_funcionario = $_POST['funcionario_id_funcionario'];
				$modelo_id_modelo = $_POST['modelo_id_modelo'];
				$data = $_POST['data_venda'];
				$valor = $_POST['valor_venda'];

				$sql = "UPDATE venda SET cliente_id_cliente='{$cliente_id_cliente}', funcionario_id_funcionario='{$funcionario_id_funcionario}', modelo_id_modelo='{$modelo_id_modelo}', data_venda='{$data}', valor_venda={$valor} WHERE id_venda=".$_REQUEST['id_venda'];

				$res = $conn->query($sql);

				if($res == true){
					print "<script>alert('Editou com sucesso');</script>";
					print "<script>location.href='?page=listar-venda';</script>";
				}else{
					print "<script>alert('Não editou');</script>";
					print "<script>location.href='?page=listar-venda';</script>";
				}
				break;

			case 'excluir':
				$sql = "DELETE FROM venda WHERE id_venda=".$_REQUEST['id_venda'];

				$res = $conn->query($sql);

				if($res == true){
					print "<script>alert('Excluiu com sucesso');</script>";
					print "<script>location.href='?page=listar-venda';</script>";
				}else{
					print "<script>alert('Não excluiu');</script>";
					print "<script>location.href='?page=listar-venda';</script>";
				}
				break;
		}	