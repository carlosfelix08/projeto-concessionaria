<?php
	$sql = "SELECT * FROM venda WHERE id_venda = ".$_REQUEST['id_venda'];
	$res = $conn->query($sql);
	$row = $res->fetch_object();
?>

<div class="conteudo-painel">
    <h1>Editar Venda</h1>
    <form action="?page=salvar-venda" method="POST">
        <input type="hidden" name="acao" value="editar">
        <input type="hidden" name="id_venda" value="<?php print $row->id_venda; ?>">
        
        <div class="mb-3">
            <label class="form-label">Cliente</label>
            <select name="cliente_id_cliente" class="form-select">
                <option>-= Escolha =-</option>
                <?php
                    $sql_1 = "SELECT * FROM cliente";
                    $res_1 = $conn->query($sql_1);
                    $qtd_1 = $res_1->num_rows;
                    if($qtd_1 > 0){
                        while($row_1 = $res_1->fetch_object()){
                            if($row->cliente_id_cliente == $row_1->id_cliente){
                                print "<option value='{$row_1->id_cliente}' selected>{$row_1->nome_cliente}</option>";
                            }else{
                                print "<option value='{$row_1->id_cliente}'>{$row_1->nome_cliente}</option>";
                            }
                        }
                    }else{
                        print "<option>Não há clientes registrados</option>";
                    }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Funcionário</label>
            <select name="funcionario_id_funcionario" class="form-select">
                <option>-= Escolha =-</option>
                <?php
                    $sql_2 = "SELECT * FROM funcionario";
                    $res_2 = $conn->query($sql_2);
                    $qtd_2 = $res_2->num_rows;
                    if($qtd_2 > 0){
                        while($row_2 = $res_2->fetch_object()){
                            if($row->funcionario_id_funcionario == $row_2->id_funcionario){
                                print "<option value='{$row_2->id_funcionario}' selected>{$row_2->nome_funcionario}</option>";
                            }else{
                                print "<option value='{$row_2->id_funcionario}'>{$row_2->nome_funcionario}</option>";
                            }
                        }
                    }else{
                        print "<option>Não há funcionários registrados</option>";
                    }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Modelo</label>
            <select name="modelo_id_modelo" class="form-select">
                <option>-= Escolha =-</option>
                <?php
                    $sql_3 = "SELECT * FROM modelo";
                    $res_3 = $conn->query($sql_3);
                    $qtd_3 = $res_3->num_rows;
                    if($qtd_3 > 0){
                        while($row_3 = $res_3->fetch_object()){
                            if($row->modelo_id_modelo == $row_3->id_modelo){
                                print "<option value='{$row_3->id_modelo}' selected>{$row_3->nome_modelo}</option>";
                            }else{
                                print "<option value='{$row_3->id_modelo}'>{$row_3->nome_modelo}</option>";
                            }
                        }
                    }else{
                        print "<option>Não há modelos registrados</option>";
                    }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Data da Venda</label>
            <input type="date" name="data_venda" class="form-control" value="<?php print $row->data_venda; ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Valor (R$)</label>
            <input type="number" step="0.01" name="valor_venda" class="form-control" value="<?php print $row->valor_venda; ?>">
        </div>

        <div class="mt-4">
            <button type="submit" class="btn btn-primary">Salvar Alterações</button>
        </div>
    </form>
</div>